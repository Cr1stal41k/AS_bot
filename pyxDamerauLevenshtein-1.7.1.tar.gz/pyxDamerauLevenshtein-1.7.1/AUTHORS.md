# Authors

## Maintainer

Geoffrey Fairchild
* [https://www.gfairchild.com/](https://www.gfairchild.com/)
* [https://github.com/gfairchild](https://github.com/gfairchild)
* [https://www.linkedin.com/in/gfairchild/](https://www.linkedin.com/in/gfairchild/)

## Contributors

Sorted by date of first contribution:

* [mittagessen](https://github.com/mittagessen)
* [Anirudha Bose](https://github.com/onyb)
* [Markus Konrad](https://github.com/internaut)
* [Simone Basso](https://github.com/simobasso)
* [Andrew Lensen](https://github.com/AndLen)
* [Sergiusz Bleja](https://github.com/svenski)
